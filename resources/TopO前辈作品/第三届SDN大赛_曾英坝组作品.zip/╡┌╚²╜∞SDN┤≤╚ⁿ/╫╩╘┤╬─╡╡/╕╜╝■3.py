# coding=utf-8

'''
	使用于  第3题  
	该代码功能为在Mininet中创建第3题topo
	电子科技大学 IMBA小组
	创建5个主机，2个交换机
'''

from mininet.topo import Topo
class MyTopo( Topo ):
     def __init__(self):

          #Initialize topology
          Topo.__init__( self )

          #Add hosts and switches
          Host1 = self.addHost( 'H1')
          Host2 = self.addHost( 'H2')
          Host3 = self.addHost( 'H3')
          Host4 = self.addHost( 'H4')
          Host4 = self.addHost( 'Web')
          Switch1 = self.addSwitch( 'S1')
          Switch2 = self.addSwitch( 'S2')

          #Add links
          self.addLink( Switch1, Switch2 )
          self.addLink( Switch2, Host5 )
          self.addLink( Host1, Switch1 )
          self.addLink( Host2, Switch1 )
          self.addLink( Host3, Switch1 )
          self.addLink( Host4, Switch1 )

topos = { 'mytopo' : (lambda: MyTopo() ) }

