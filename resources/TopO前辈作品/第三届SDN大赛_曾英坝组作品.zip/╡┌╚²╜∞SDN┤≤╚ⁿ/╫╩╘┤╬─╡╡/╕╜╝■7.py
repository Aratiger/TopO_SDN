# coding=utf-8

'''
	使用于  第4题  
	该代码功能：
	
	得到交换机的流表，进行解析
	返回数据包路由的路径
	GUI交互
		
	电子科技大学 IMBA小组
	创建4个主机，4个交换机
'''

from __future__ import print_function
import pygtk
pygtk.require('2.0')
import gtk

import json
import requests
from requests.auth import HTTPBasicAuth


class OpenDaylight(object):
    def __init__(self):
        self.setup = {'hostname': 'localhost',
                      'port': '8181',
                      'username': 'admin',
                      'password': 'admin',
                      'path': '/restconf/',
                      'http': 'http://'}

        self._base_url = None
        self.url = None
        self.auth = None

    def prepare(self, app, path):
        """Sets up the necessary details for the REST connection by calling
           prepare_url and prepare_auth.

           Arguments:
            'app'  - which OpenDaylight northbound api component (application)
                     we want to talk to.
            'path' - the specific rest query for the application.
        """
        self.prepare_url(app, path)
        self.prepare_auth()

    def prepare_url(self, app, path):
        self.url = self.setup['http'] + self.setup['hostname'] + ':' + \
                   self.setup['port'] + self.setup['path'] + app + path

    def prepare_auth(self):
        self.auth = HTTPBasicAuth(self.setup['username'],
                                  self.setup['password'])

#获取流表的方法在OpenDaylightFlow类中

class OpenDaylightFlow(object):
    def __init__(self, odl):
        """Mandatory argument:
            odl      - an OpenDaylight object
        """
        self.odl = odl
        self.__app = 'config/opendaylight-inventory:nodes/node/openflow:2'
        self.request = None
        self.flows = None

    def get(self, node_id=None):

        # clear out any remaining crud from previous calls
        if hasattr(self, 'request'):
            del self.request
        if hasattr(self, 'flows'):
            del self.flows

        self.odl.prepare(self.__app, '/node/openflow:' + node_id)

        self.request = requests.get(url=self.odl.url, auth=self.odl.auth)

        if self.request.status_code == 200:
            self.flows = self.request.json()
        else:
            raise OpenDaylightError({'url': self.odl.url,
                                     'http_code': self.request.status_code,
                                     'msg': self.request.text})



class OpenDaylightError(Exception):
    """OpenDaylight Exception Class
    """
    pass

class switch:

    def __init__(self):
        self.out = {
            '1' : 's2',
            '2' : 's3',
            '3' : 'h1'
        }


class MyProgram:


    def __init__(self,Flowlist):

        self.Flowlist=Flowlist
        self.src.ip = '0'
        self.des.ip = '0'
        self.out={
            '1' : 's1',
            '2' : 's1',
            '3' : 's4',
            '4' : 's4'
        }
        self.road = ' '


        # 创建一个新窗口
        app_window = gtk.Window(gtk.WINDOW_TOPLEVEL)
        app_window.set_size_request(500, 350 )
        app_window.set_border_width(10)
        app_window.set_title("路由路径验证1.0")
        app_window.connect("delete_event", lambda w,e: gtk.main_quit())

        # Program goes here  ...

        fix = gtk.Fixed()

        vbox =gtk.VBox(True,5)

        src =gtk.HBox(False)
        src1 =gtk.Label('  源IP:')
        src1.set_size_request(61,28)
        src2 =gtk.Entry()
        src2.set_size_request(180, 28)
        src.pack_start(src1)
        src.pack_start(src2)

        des = gtk.HBox(False)
        des1 = gtk.Label('目的IP:')
        des1.set_size_request(61, 28)
        des2 = gtk.Entry()
        des2.set_size_request(180,28)
        des.pack_start(des1)
        des.pack_start(des2)

        vbox.add(src)
        vbox.add(des)
        btn1 =gtk.Button('确定')
        btn1.connect('clicked',self.find_route(self.Flowlist))

        hbox = gtk.VBox(True)
        #将标签与路由路径关联
        route =gtk.Label(self.find_route(self.Flowlist))
        route.set_size_request(60,40)
        rt = gtk.Label('经分析报文传输路径为:')
        hbox.pack_start(rt)
        hbox.pack_start(route)

        fix.put(vbox,50,120)
        fix.put(hbox,50,245)
        fix.put(btn1,270,184)
        app_window.add(fix)


        app_window.show_all()
        return

    #逐一分析流表，找到路径
    def find_route(self,Flist):
        Current_sw =self.out[self.src_ip]
        self.road = Current_sw
        for element in Flist  #遍历列表
            if element.src_ip==self.src_ip & element.des_ip==self.des_ip:
                if element == Current_sw
                    #符合条件则加入路径中
                    self.road += Currrent_sw.out( element.output )


#将json转化为字典类型
def js_trans_dit(table):

    tem_list=(json.loads(table))
    return tem_list


def main():
    gtk.main()
    return 0

if __name__ == "__main__":
    odl1 = OpenDaylight()
    user = OpenDaylightFlow(odl1)

    #获取交换机1-4上的流表，同时进行python与json对象的转换
    user.get(1)
    table1 = js_trans_dit(user.flows)
    user.get(2)
    table2 = js_trans_dit(user.flows)
    user.get(3)
    table3 = js_trans_dit(user.flows)
    user.get(4)
    table4 = js_trans_dit(user.flows)

    Flist=(table1, table2, table3 ,table4 )
    MyProgram(Flist)
    main()
