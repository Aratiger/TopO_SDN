# coding=utf-8
from __future__ import print_function
import pygtk
pygtk.require('2.0')
import gtk

import json
import requests
from requests.auth import HTTPBasicAuth


class OpenDaylight(object):
    def __init__(self):
        self.setup = {'hostname': 'localhost',
                      'port': '8181',
                      'username': 'admin',
                      'password': 'admin',
                      'path': '/restconf/',
                      'http': 'http://'}

        self._base_url = None
        self.url = None
        self.auth = None

    def prepare(self, app, path):
        """Sets up the necessary details for the REST connection by calling
           prepare_url and prepare_auth.

           Arguments:
            'app'  - which OpenDaylight northbound api component (application)
                     we want to talk to.
            'path' - the specific rest query for the application.
        """
        self.prepare_url(app, path)
        self.prepare_auth()

    def prepare_url(self, app, path):
        self.url = self.setup['http'] + self.setup['hostname'] + ':' + \
                   self.setup['port'] + self.setup['path'] + app + path

    def prepare_auth(self):
        self.auth = HTTPBasicAuth(self.setup['username'],
                                  self.setup['password'])


class OpenDaylightFlow(object):
    def __init__(self, odl):
        """Mandatory argument:
            odl      - an OpenDaylight object
        """
        self.odl = odl
        self.__app = 'config/opendaylight-inventory:nodes/node/openflow:2'
        self.request = None
        self.flows = None

    def get(self, node_id=None):

        # clear out any remaining crud from previous calls
        if hasattr(self, 'request'):
            del self.request
        if hasattr(self, 'flows'):
            del self.flows

        self.odl.prepare(self.__app, '/node/openflow:' + node_id)

        self.request = requests.get(url=self.odl.url, auth=self.odl.auth)

        if self.request.status_code == 200:
            self.flows = self.request.json()
            print(self.flows)
        else:
            raise OpenDaylightError({'url': self.odl.url,
                                     'http_code': self.request.status_code,
                                     'msg': self.request.text})

    def add(self, flow, node_id):
        if hasattr(self, 'request'):
            del self.request
        self.odl.prepare(self.__app, '/flow-node-inventory:table/0/flow/' + node_id)
        headers = {'Content-type': 'application/json'}
        body = json.dumps(flow)
        self.request = requests.put(url=self.odl.url, auth=self.odl.auth,
                                    data=body, headers=headers)

        if self.request.status_code != 200:
            raise OpenDaylightError({'url': self.odl.url,
                                     'http_code': self.request.status_code,
                                     'msg': self.request.text})
        else:
            print('success!')

        def delete(self, node_id):

            if hasattr(self, 'request'):
                del self.request

            self.odl.prepare(self.__app, '/flow-node-inventory:table/0/flow/' + node_id)
            self.request = requests.delete(url=self.odl.url, auth=self.odl.auth)
            if self.request.status_code != 200:
                raise OpenDaylightError({'url': self.odl.url,
                                         'http_code': self.request.status_code,
                                         'msg': self.request.text})
            else:
                print("delete success!")


class OpenDaylightError(Exception):
    """OpenDaylight Exception Class
    """
    pass


flow1 = {
    "flow": [
        {
            "id": "1",
            "match": {
                "ethernet-match": {
                    "ethernet-source": {
                        "address": "1e:a8:68:39:3a:63"
                    },
                    "ethernet-type": {
                        "type": "0x0800"
                    }
                }
            },
            "instructions": {
                "instruction": [
                    {
                        "apply-actions": {
                            "action": [
                                {
                                    "drop-action": {},
                                    "order": "0"
                                }
                            ]
                        },
                        "order": "0"
                    }
                ]
            },
            "flow-name": "flow1",
            "priority": "123",
            "table_id": "0"
        }
    ]
}

flow4 = {
    "flow": [
        {
            "id": "4",
            "match": {
                "ethernet-match": {
                    "ethernet-source": {
                        "address": "ee:b0:93:5e:73:04"
                    },
                    "ethernet-type": {
                        "type": "0x0800"
                    }
                }
            },
            "instructions": {
                "instruction": [
                    {
                        "apply-actions": {
                            "action": [
                                {
                                    "drop-action": {},
                                    "order": "0"
                                }
                            ]
                        },
                        "order": "0"
                    }
                ]
            },
            "flow-name": "flow4",
            "priority": "123",
            "table_id": "0"
        }
    ]
}

flow3 = {
    "flow": [
        {
            "id": "3",
            "match": {
                "ethernet-match": {
                    "ethernet-source": {
                        "address": "02:dc:10:29:c5:de"
                    },
                    "ethernet-type": {
                        "type": "0x0800"
                    }
                }
            },
            "instructions": {
                "instruction": [
                    {
                        "apply-actions": {
                            "action": [
                                {
                                    "drop-action": {},
                                    "order": "0"
                                }
                            ]
                        },
                        "order": "0"
                    }
                ]
            },
            "flow-name": "flow3",
            "priority": "123",
            "table_id": "0"
        }
    ]
}

flow2 = {
    "flow": [
        {
            "id": "2",
            "match": {
                "ethernet-match": {
                    "ethernet-source": {
                        "address": "42:d4:e8:ca:67:39"
                    },
                    "ethernet-type": {
                        "type": "0x0800"
                    }
                }
            },
            "instructions": {
                "instruction": [
                    {
                        "apply-actions": {
                            "action": [
                                {
                                    "drop-action": {},
                                    "order": "0"
                                }
                            ]
                        },
                        "order": "0"
                    }
                ]
            },
            "flow-name": "flow2",
            "priority": "123",
            "table_id": "0"
        }
    ]
}

# 设置4个主机的状态变量
global h1
h1 ='可访问'
global h2
h2 ='可访问'
global h3
h3 ='可访问'
global h4
h4 ='可访问'


class MyProgram:


    def __init__(self,odlFlow):

        self.odlFlow=odlFlow

        # create a new window
        app_window = gtk.Window(gtk.WINDOW_TOPLEVEL)
        app_window.set_size_request(618, 392)
        app_window.set_border_width(10)
        app_window.set_title("web访问应用配置1.0")
        app_window.connect("delete_event", lambda w,e: gtk.main_quit())

        # Program goes here  ...

        table_layout = gtk.Table(rows=3, columns=5, homogeneous=True)
        label_a = gtk.Label("主机")
        label_a.set_size_request(123,120)
        label_a.show()
        table_layout.attach(label_a, 0, 1, 0, 1, 0, 0, 0, 0)
        label_b = gtk.Label("主机状态")
        label_b.show()
        table_layout.attach(label_b, 0, 1, 1, 2, 0, 0, 0, 0)

        label_c = gtk.Label("主机H1")
        label_c.show()
        table_layout.attach(label_c, 1, 2, 0, 1, 0, 0, 0, 0)
        label_d = gtk.Label("主机H2")
        label_d.show()
        table_layout.attach(label_d, 2, 3, 0, 1, 0, 0, 0, 0)
        label_e = gtk.Label("主机H3")
        label_e.show()
        table_layout.attach(label_e, 3, 4, 0, 1, 0, 0, 0, 0)
        label_f = gtk.Label("主机H4")
        label_f.show()
        table_layout.attach(label_f, 4, 5, 0, 1, 0, 0, 0, 0)

        label_b1 = gtk.Label(h1)
        label_b1.show()
        table_layout.attach(label_b1, 1, 2, 1, 2, 0, 0, 0, 0)
        label_b2 = gtk.Label(h2)
        label_b2.show()
        table_layout.attach(label_b2, 2, 3, 1, 2, 0, 0, 0, 0)
        label_b3 = gtk.Label(h3)
        label_b3.show()
        table_layout.attach(label_b3, 3, 4, 1, 2, 0, 0, 0, 0)
        label_b4 = gtk.Label(h4)
        label_b4.show()
        table_layout.attach(label_b4, 4, 5, 1, 2, 0, 0, 0, 0)

        btn1 = gtk.Button("H1状态转换")
        btn1.set_size_request(90, 40)
        btn1.connect("clicked", self.on_click1)
        btn1.show()
        table_layout.attach(btn1, 1, 2, 2, 3, 0, 0, 0, 0)
        btn2 = gtk.Button("H2状态转换")
        btn2.set_size_request(90, 40)
        btn2.connect("clicked", self.on_click2)
        btn2.show()
        table_layout.attach(btn2, 2, 3, 2, 3, 0, 0, 0, 0)
        btn3 = gtk.Button("H3状态转换")
        btn3.set_size_request(90, 40)
        btn3.show()
        table_layout.attach(btn3, 3, 4, 2, 3, 0, 0, 0, 0)
        btn4 = gtk.Button("H4状态转换")
        btn4.set_size_request(90, 40)
        btn4.show()
        table_layout.attach(btn4, 4, 5, 2, 3, 0, 0, 0, 0)

        table_layout.show()

        app_window.add(table_layout)


        app_window.show()
        return
    def on_click1(self,widget):
        self.odlFlow.add(flow1,'1')
        print(h1)
    def on_click2(self,widget):
        self.odlFlow.add(flow2,'2')
        print(h2)



def main():
    gtk.main()
    return 0

if __name__ == "__main__":
    odl1 = OpenDaylight()
    user = OpenDaylightFlow(odl1)
    MyProgram(user)
    main()
